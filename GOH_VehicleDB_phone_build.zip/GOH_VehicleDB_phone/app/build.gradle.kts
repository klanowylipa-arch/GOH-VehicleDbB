plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.goh.vehicledb"; compileSdk=35
 defaultConfig { applicationId="com.goh.vehicledb"; minSdk=26; targetSdk=35; versionCode=3; versionName="0.3" }
}

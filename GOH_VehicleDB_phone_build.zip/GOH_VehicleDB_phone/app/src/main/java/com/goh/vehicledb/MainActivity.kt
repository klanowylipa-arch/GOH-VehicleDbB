package com.goh.vehicledb
import android.app.*;import android.os.*;import android.graphics.Color;import android.view.*;import android.widget.*
data class V(val n:String,val f:String,val e:String,val t:String,val g:String,val a:String,val d:String)
class MainActivity:Activity(){
 val vs=listOf(
 V("Tiger II H","Niemcy","Late","Ciężki","8.8 cm KwK 43 L/71","150/80/80 mm","Brak danych DP/CP"),
 V("Tiger I","Niemcy","Late","Ciężki","8.8 cm KwK 36 L/56","100/82/82 mm","Brak danych DP/CP"),
 V("Panther G","Niemcy","Late","Średni","7.5 cm KwK 42 L/70","80/50/40 mm","Brak danych DP/CP"),
 V("SU-100","ZSRR","Late","Niszczyciel","100 mm D-10S","75/45/20 mm","Defensive • DP/CP do importu"),
 V("IS-2 1944","ZSRR","Late","Ciężki","122 mm D-25T","120/90/60 mm","Brak danych DP/CP"),
 V("M36 Jackson","USA","Late","Niszczyciel","90 mm M3","76/19/19 mm","Offensive / Irregular"),
 V("M26 Pershing","USA","Late","Ciężki","90 mm M3","102/76/51 mm","Brak danych DP/CP"),
 V("Sherman Firefly","Commonwealth","Late","Średni","17-pounder","64/38/38 mm","Offensive"),
 V("Archer","Commonwealth","Late","Niszczyciel","17-pounder","60/20/20 mm","Offensive")
 )
 fun root()=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,25,22,18);setBackgroundColor(Color.rgb(18,18,16))}
 fun tv(s:String,size:Float=18f)=TextView(this).apply{text=s;textSize=size;setTextColor(Color.WHITE)}
 fun home(){val r=root();r.addView(tv("GATES OF HELL\nVEHICLE DATABASE",23f),LinearLayout.LayoutParams(-1,90));r.addView(tv("v0.3 • wersja do budowania na telefonie",15f));val b=Button(this);b.text="POJAZDY";b.setOnClickListener{vehicles()};r.addView(b);val c=Button(this);c.text="KONTRA KING TIGER";c.setOnClickListener{counter()};r.addView(c);val d=Button(this);d.text="DOKTRYNY / DP / CP";d.setOnClickListener{doctrines()};r.addView(d);setContentView(r)}
 fun vehicles(){val r=root();val back=Button(this);back.text="← MENU";back.setOnClickListener{home()};r.addView(back);r.addView(tv("POJAZDY",22f));val q=EditText(this);q.hint="Szukaj pojazdu / frakcji";q.setTextColor(Color.WHITE);q.setHintTextColor(Color.GRAY);r.addView(q);val l=ListView(this);r.addView(l,LinearLayout.LayoutParams(-1,0,1f));fun x(s:String){val z=vs.filter{ s.isBlank()||"${it.n} ${it.f} ${it.e} ${it.t} ${it.g}".contains(s,true)};l.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_2,android.R.id.text1,z.map{it.n}.toTypedArray());l.setOnItemClickListener{_,_,p,_->val v=z[p];AlertDialog.Builder(this).setTitle(v.n).setMessage("Frakcja: ${v.f}\nEra: ${v.e}\nTyp: ${v.t}\nDziało: ${v.g}\nPancerz: ${v.a}\nDoktryna: ${v.d}").setPositiveButton("OK",null).show()}};x("");q.addTextChangedListener(object:android.text.TextWatcher{override fun beforeTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){};override fun onTextChanged(s:CharSequence?,a:Int,b:Int,c:Int){x(s?.toString()?:"")};override fun afterTextChanged(e:android.text.Editable?){}});setContentView(r)}
 fun counter(){val r=root();r.addView(Button(this).apply{text="← MENU";setOnClickListener{home()}});r.addView(tv("KONTRA KING TIGER",22f));r.addView(tv("\nNa tym etapie aplikacja pokazuje strukturę porównywarki.\n\nNajlepsze kandydaty z przykładowej bazy:\n• SU-100 — 100 mm D-10S\n• M36 Jackson — 90 mm M3\n• Sherman Firefly — 17-pounder\n• IS-2 1944 — 122 mm D-25T\n\nPełne wyniki penetracji po dystansie zostaną wyliczone po imporcie aktualnych danych gry."));setContentView(r)}
 fun doctrines(){val r=root();r.addView(Button(this).apply{text="← MENU";setOnClickListener{home()}});r.addView(tv("DOKTRYNY / DP / CP",22f));r.addView(tv("\nPrzygotowane pola danych:\n• frakcja\n• doktryna\n• tier\n• koszt DP\n• koszt CP\n• jednostka\n\nNie wpisuję fikcyjnych kosztów. Po eksporcie z gry baza zostanie automatycznie uzupełniona."));setContentView(r)}
 override fun onCreate(b:Bundle?){super.onCreate(b);home()}
}

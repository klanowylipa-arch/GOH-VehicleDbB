# GOH Vehicle DB v0.3 — build from phone

Projekt jest przygotowany pod GitHub Actions. Nie wymaga Android Studio na telefonie.

## Najprościej
1. Utwórz repozytorium GitHub i wgraj cały folder projektu.
2. GitHub Actions automatycznie uruchomi workflow z `.github/workflows/build-apk.yml`.
3. Po zakończeniu pobierz artefakt `GOH-VehicleDB-debug-apk`.
4. Na telefonie pobierz APK i zezwól przeglądarce/menedżerowi plików na instalację aplikacji z tego źródła.

Wersja 0.3 zawiera działającą aplikację z przykładową bazą. Pełne DP/CP i pełny dataset wymagają późniejszego eksportu danych z gry.
